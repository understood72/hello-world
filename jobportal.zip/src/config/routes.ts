import { Request, Response, NextFunction } from 'express';
import { UserController } from '../controllers/User';
import { CommonController } from '../controllers/Common';
import { JobsController } from '../controllers/Jobs';
export class Routes {
    user = new UserController();
    cmn = new CommonController();
    job = new JobsController();
    navigate(router: any) {
        var self = this;
        router.get('/job001', (req: Request, res: Response, next: NextFunction) => {
            console.log('here');
            res.send('here');
            const post = req.body;
            switch (post.act) {
                case 'job001':
                    /* Add User Type */
                    this.user.addUserType(req, res, next);
                    break;
                case 'job002':
                    /* Add New USer */
                    const user = new UserController();
                    this.user.addUser(req, res, next, function (err: any, results: any) { 
                        if(err) {
                            self.cmn.showMsg(res, err);
                        }
                        if(err) {
                            self.cmn.showMsg(res, results);
                        }
                    });
                    break;
                case 'job003':
                    /* User Login */
                    this.user.login(req, res, next);
                    break;
                case 'job004':
                    /* Add Business Stream */
                    this.cmn.addBStream(req, res, next);
                    break;
                case 'job005':
                    /* Add Business Stream */
                    this.cmn.addCompany(req, res, next);
                    break;
                case 'job006':
                    /* Add Job Seeker */
                    /* Create Login account then create a seeker profile */
                    this.user.addSeeker(req, res, next);
                    break;
                case 'job007':
                    /* Add Recruiter Account */
                    this.user.addRecruiter(req, res, next);
                    break;
                case 'job008':
                    /* Add Job */
                    this.job.add(req, res, next);
                    break;
                case 'job009':
                    /* Add Job */
                    this.user.getUsers(req, res, next);
                    break;
                case 'job010':
                    /* Get Job */
					console.log(req.body);
                    this.job.getJobs(req, res, next);
                    break;

            }
        })

    }
}
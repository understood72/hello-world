import express from 'express';
import * as bodyParser from 'body-parser';
const compression = require('compression');
const cors = require("cors");
const dotenv = require("dotenv");
const mongoose = require('mongoose');
const bluebird = require('bluebird');
import { Routes } from './config/routes';
import { UserController } from './controllers/User';
/**
 * Load environment variables from .env file, where API keys and passwords are configured.
 */
dotenv.config({ path: ".env.example" });

mongoose.Promise = bluebird;
const app = express() 
const router = express.Router();
mongoose.connect('mongodb://localhost:27017/jobportal', {useNewUrlParser: true}).then(() => {
    console.log('DB Connected');
});
mongoose.connection.on("error", () => {
    console.log("MongoDB connection error. Please make sure MongoDB is running.");
    process.exit();
  });

const routes = new Routes();
routes.navigate(router);
// const user = new UserController();
// app.post('/', user.addUser);
app.use(bodyParser.json({ limit: '50mb' }));
    app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(cors());
app.use('/', router);
// app.use(compression());
app.set("port", process.env.PORT || 3000);
app.use((req, res, next) => {
    next();
});
const newLocal = '/public';
app.use(express.static(__dirname + newLocal, { maxAge: 31557600000 }));
console.log(function() {    
});
/**
 * Start Express server.
 */
app.listen(app.get("port"), () => {
    console.log(("App is running at http://localhost:%d in %s mode"), app.get("port"), app.get("env"));
    console.log("Press CTRL-C to stop\n");
});

module.exports = app;

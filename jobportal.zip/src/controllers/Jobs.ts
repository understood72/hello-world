import * as assert from 'assert';
import { Request, Response, NextFunction } from 'express';
const mongoose = require('mongoose');
const Promise = require('bluebird');
const Jobs = require("../models/Jobs");
import { CommonController } from '../controllers/Common';
mongoose.Promise = Promise;
let cmn = new CommonController();
export class JobsController {
    add(req: Request, res: Response, next: NextFunction) {
        const post = req.body;
        let info = { status: 0, message: '', data: [] };
        const data = {
            posted_by_id: post.posted_by_id,
            job_type_id: post.job_type_id,
            company_id: post.company_id,
            is_company_name_hidden: post.is_company_name_hidden,
            job_title: post.job_title,
            job_description: post.job_description,
            salary: post.salary,
            country: post.country,
            state: post.state,
            city: post.city,
            zip: post.zip,
            street_address: post.street_address,
            lat: post.lat,
            lng: post.lng
        }

        const job = new Jobs(data);
        let promise = job.save();
        assert.ok(promise instanceof Promise);
        promise.then(function (doc: any) {
            info.status = 1;
            info.message = `Job added successfully.`;
            info.data = job;
            cmn.showMsg(res, info);
        }).catch(function (err: any) {
            if (err) {
                info.message = `Job couldn't added due to some technical issue.`;
                cmn.showMsg(res, info);
            }
        });
    }

    getJobs(req: Request, res: Response, next: NextFunction) {
        const post = req.body;
		let info = {status: 0, message: '', data: ''};
        let data = {
            job_title: post.kw
        }
        let job = new Jobs(data);
        job.getJobs((err: any, results: any) => {
            if (err != null) {
                res.end('' + JSON.stringify(err));
            }
            if (results != null) {
				info.status = 1;
				info.message = `Total ${results.length} jobs found.`
				info.data = results;
                cmn.showMsg(res, info);
            }
        });

    }
}

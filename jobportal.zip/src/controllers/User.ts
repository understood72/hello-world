import * as assert from 'assert';
import { Request, Response, NextFunction } from 'express';
import { resolve } from 'url';
const mongoose = require('mongoose');
const Promise = require('bluebird');
const bcrypt = require('bcrypt');
// import { UserType } from '../models/UserType';
const UserType = require("../models/UserType");
const User = require("../models/User");
const Seeker = require('../models/Seeker');
const UserLog = require('../models/UserLog');


mongoose.Promise = Promise;
export class UserController {
    saltRounds = 10;
    constructor() {
    }

    addUserType(req: Request, res: Response, next: NextFunction) {
        const post = req.body;
        const data = {
            user_type: post.user_type
        }
        const utype = new UserType(data);
        let info = { status: 0, message: '', data: {} };
        utype.isExist(function (err: any, results: any) {
            if (err) {
                info.message = `There is a problem while adding user type`;
            }
            if (results) {
                info.message = `User type '${post.user_type}' alerady added`;
            }
            if (results == null) {
                var promise = utype.save();
                assert.ok(promise instanceof Promise);
                promise.then(function (doc: any) {
                    info.status = 1;
                    info.message = `User type added`;
                    info.data = utype;
                    res.end('' + JSON.stringify(info));
                }).catch((err: any) => {
                    info.message = `User type couldn't added`;
                    res.end('' + JSON.stringify(info));
                });
            } else {
                res.end('' + JSON.stringify(info));
            }

        });
    }
    addUser(req: Request, res: Response, next: NextFunction, cb: any) {
        const post = req.body;
        let info = { status: 0, message: '', data: {} };
        let data = {
            user_type_id: post.user_type_id,
            email: post.email,
            password: post.password,
            dob: post.dob,
            gender: post.gender,
            status: 1,
            sms_notification_active: post.sms_notification_active,
            email_notification_active: post.email_notification_active,
            created_at: new Date().getTime()
        }
        /* Generating hash to convert user password */
        bcrypt.genSalt(10, function (err: any, salt: any) {
            bcrypt.hash(post.password, salt, function (err: any, hash: any) {
                data.password = hash;
                const user = new User(data);
                user.isExist(function (err: any, results: any) {
                    if (err) {
                        
                        info.message = `User couldn't added due to some technical issue.`;
                        // res.end('' + JSON.stringify(info));
                        return cb(info, null);
                    }
                    
                    if (results == null) {
                        let promise = user.save();
                        assert.ok(promise instanceof Promise);
                        promise.then(function (doc: any) {
                            info.status = 1;
                            info.message = `User added successfully.`;
                            info.data = user;
                            // res.end('' + JSON.stringify(info));
                            return cb(null, info);
                        },console.error).catch(function (err: any) {
                            if (err) {
                                info.message = `User couldn't added due to some technical issue.`;
                                // res.end('' + JSON.stringify(info));
                                return cb(info, null);
                            }
                        })
                    } else {
                        info.message = `User '${post.email}' already exists`;
                        // res.end('' + JSON.stringify(info));
                        return cb(info, null);
                    }
                });
            });
        });



        /* user.save((err: any) => {
            if (err) {
                console.log(err);
            }
            console.log(`User added ${user.id}`);
            let info = { status: 1, message: 'User Added', data: user };
            res.end('' + JSON.stringify(info));
        }); */
    }

    getUsers(req: Request, res: Response, next: NextFunction) {
        const post = req.body;
        let data = {
            user_type_id: post.user_type_id,
        };
        let user = new User(data);
        user.getUsers((err: any, results: any) => {
            if(err != null) {
                res.end(''+ JSON.stringify(err));
            }
            if(results != null) {
                res.end(''+ JSON.stringify(results));
            }
        });
    }

    private getSelf() {
        return this;
    }

    login(req: Request, res: Response, next: NextFunction) {
        let post = req.body;
        // let user = new User();
        let info = { status: 0, message: '', data: {} };
        User.findOne({ email: post.email, password: post.password }, function (err: any, doc: any) {
            if (err) {
                info.message = `No Record found`;
                res.end('' + JSON.stringify(info));
            }
            if (doc) {
                info.status = 1;
                info.message = `Record found`;
                info.data = doc;

                /* Update Log */
                let data = { user_id: doc.id, last_login_date: new Date().getDate() };
                let userlog = new UserLog(data);
                userlog.save();
                res.end('' + JSON.stringify(info));
            } else {
                info.message = `No Record found`;
                res.end('' + JSON.stringify(info));
            }

        });
    }

    addSeeker(req: Request, res: Response, next: NextFunction) {
        /* Using bluebird promisify function converting callback function into promise */
        const newUser = Promise.promisify(this.addUser);
        const seekerProfile = Promise.promisify(this.updateSeeker);
        let info = { status: 0, message: '', data: {} }
        newUser(req, res, next).then((results: any) => {
            if (results.status == 1) {
                /* Login credential created for job seeker */
                let post = req.body;
                let user = results.data;
                let data = {
                    user_id: user._id,
                    first_name: post.first_name,
                    last_name: post.last_name,
                    current_salary: post.current_salary,
                    is_annually_monthly: post.is_annually_monthly,
                    currency: post.currency,
                    created_at: new Date().getTime()
                }
                console.log(data);
                seekerProfile(data).then(function (results: any) {
                    info.status = 1;
                    info.message = 'Seeker add successfully';
                    info.data = results;
                    res.end('' + JSON.stringify(info));
                }).catch(function (err: any) {
                    User.findOneAndDelete({ _id: user._id }, {}, function (delerr: any, delres: any) {
                        info.status = 0;
                        info.message = `Seeker profile couldn't added`;
                        info.data = err.message;
                        res.end('' + JSON.stringify(info));
                    });

                })
            }

        }).catch((err: any) => {
            res.end('' + JSON.stringify(err));
        });
    }

    updateSeeker(post: any, cb: any) {
        let query = {};
        if (post.user_id != undefined) {
            query = {
                user_id: post.user_id
            }
        }
        var options = {
            // Return the document after updates are applied
            new: true,
            // Create a document if one isn't found. Required
            // for `setDefaultsOnInsert`
            upsert: true,
            setDefaultsOnInsert: true
        }
        Seeker.findOneAndUpdate(query, { $set: post }, options, function (err: any, results: any) {
            if (err != null) {
                return cb(err, null);
            }
            if (results != null) {
                return cb(null, results);
            }
        });
    }

    addRecruiter(req: Request, res: Response, next: NextFunction) {
        const newUser = Promise.promisify(this.addUser);
        newUser(req, res, next).then(function(results: any) {
            res.end(''+JSON.stringify(results));
        }).catch(function(err: any) {
            res.end(''+JSON.stringify(err));
        });
    }
}

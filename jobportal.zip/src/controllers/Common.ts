import * as assert from 'assert';
import { Request, Response, NextFunction } from 'express';
const mongoose = require('mongoose');
const Promise = require('bluebird');
const bcrypt = require('bcrypt');
// import { UserType } from '../models/UserType';
const fs = require('fs');
const UserType = require("../models/UserType");
const User = require("../models/User");
const UserLog = require('../models/UserLog');
const BusinessStream = require('../models/BusinessStream');
const Company = require('../models/Company');
mongoose.Promise = Promise;
export class CommonController {
    saltRounds = 10;
    constructor() {
    }

    addBStream(req: Request, res: Response, next: NextFunction) {
        const post = req.body;
        const data = {
            name: post.name
        }
        const bstream = new BusinessStream(data);
        let info = { status: 0, message: '', data: {} };
        bstream.isExist(function (err: any, results: any) {
            if (err) {
                info.message = `There is a problem while adding business stream`;
            }
            if (results) {
                info.message = `Business stream '${post.name}' alerady exist`;
            }
            if (results == null) {
                var promise = bstream.save();
                assert.ok(promise instanceof Promise);
                promise.then(function (doc: any) {
                    info.status = 1;
                    info.message = `Business stream type added`;
                    info.data = bstream;
                    res.end('' + JSON.stringify(info));
                }).catch((err: any) => {
                    info.message = `Business stream couldn't added`;
                    res.end('' + JSON.stringify(info));
                });
            } else {
                res.end('' + JSON.stringify(info));
            }

        });
    }

    addCompany(req: Request, res: Response, next: NextFunction) {
        const post = req.body;
        const data = {
            name: post.name,
            business_stream_id: post.business_stream_id,
            profile_description: post.description,
            establishment_date: post.establishment_date,
            website_url: post.website_url
        }
        if(post.image != undefined && post.image !='') {
            let image = 'test.jpg';
            post.image = image;
            this.uploadBase64(post.image, 'images/'+image, function(result: any) {
                console.log(result);
            });
        }
        const cmp = new Company(data);
        let info = { status: 0, message: '', data: {} };
        cmp.isExist(function (err: any, results: any) {
            if (err) {
                info.message = `There is a problem while adding new company`;
            }
            if (results) {
                info.message = `Company '${post.name}' alerady exist`;
            }
            if (results == null) {
                var promise = cmp.save();
                assert.ok(promise instanceof Promise);
                promise.then(function (doc: any) {
                    info.status = 1;
                    info.message = `Company added successfully`;
                    info.data = cmp;
                    res.end('' + JSON.stringify(info));
                }).catch((err: any) => {
                    info.message = `Company couldn't added`;
                    res.end('' + JSON.stringify(info));
                });
            } else {
                res.end('' + JSON.stringify(info));
            }

        });
    }

    decodeBase64Image(dataString: string) {
        var matches = dataString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
        var response: any = { type: '', data: '' };
        if (matches !== null) {
            if (matches.length !== 3) {
                console.log('Invalid input string');
                return new Error('Invalid input string');
            }
            response.type = matches[1];
            //            console.log(matches[2]);
            response.data = new Buffer(matches[2], 'base64');
        }
        return response;
    }
    uploadBase64(image: string, destination: string, callback: any) {
        var data = image;
        var info = { status: '', message: '' }
        var imageBuffer: any = { data: '' };
        imageBuffer = this.decodeBase64Image(data);
        //        var imageBuffer = new Buffer(data, 'base64');
        fs.writeFile(destination, imageBuffer.data, function (err: any) {
            if (err) {
                console.log(err);
                info = { status: "error", message: 'File couldn\'t uploaded.' }
                return;
            } else {
                info = { status: "success", message: 'File uploaded successfully.' }
            }
            console.log(info);
            return callback(info);
        });
    }

    showMsg(res: Response, info: any) {
        res.end(''+ JSON.stringify(info));
    }

    
}
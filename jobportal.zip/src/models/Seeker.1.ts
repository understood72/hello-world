import { Document, Schema, Model, model} from "mongoose";
import { ObjectId } from "bson";

const CompanySchema = new Schema({
    user_id: Schema.Types.ObjectId,
    name: String,
    profile_description: String,
    business_stream_id: Schema.Types.ObjectId,
    establishment_date: Number,
    website_url: String,
    image: String,
    created_at: Number
});

CompanySchema.methods.isExist = function(cb: any) {
    return this.model('company').findOne({email: this.email}, cb);
}
const Seeker = model('company', CompanySchema);
module.exports = Seeker;
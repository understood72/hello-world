// import  * as mongoose  from "mongoose";
import { Document, Schema, Model, model} from "mongoose";

// var Schema = mongoose.Schema;

const userLogSchema = new Schema({
    user_id: Schema.Types.ObjectId,
    last_login_date: Number,
    last_job_apply_date: Number
});

const UserLog = model('user_log', userLogSchema);
module.exports = UserLog;

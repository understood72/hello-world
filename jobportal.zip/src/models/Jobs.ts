import { Document, Schema, model } from "mongoose";

interface JobSearch {
    job_title: string;
}
const JobSchema = new Schema({
    posted_by_id: Schema.Types.ObjectId,
    job_type_id: Schema.Types.ObjectId,
    company_id: Schema.Types.ObjectId,
    is_company_name_hidden: Number,
    job_title: String,
    job_description: String,
    salary: String,
    country: String,
    state: String,
    city: String,
    zip: String,
    street_address: String,
    lat: String,
    lng: String,
    status: Number,
    created_at: Number
});

JobSchema.methods.getJobs = function(cb: any) {
    let post = {
        job_title: ''
    };
    if(this.job_title !=undefined && this.job_title != '') {
        post.job_title = this.job_title;
    }    
    return model('jobs').find(this.post, cb);
}

const job = model('jobs', JobSchema);
module.exports = job;
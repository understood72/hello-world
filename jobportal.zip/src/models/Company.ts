// import  * as mongoose  from "mongoose";
import { Document, Schema, Model, model} from "mongoose";

// var Schema = mongoose.Schema;

const companySchema = new Schema({
    name: { type: String },
    profile_description: String,
    business_stream_id: Schema.Types.ObjectId,
    establishment_date: Number,
    website_url: String,
    image: String
}, {collection: 'company'});

companySchema.methods.isExist = function(cb: any) {
    return this.model('company').findOne({name: this.name, business_stream_id: this.business_stream_id}, cb);
}
const Company = model('company', companySchema);
module.exports = Company;

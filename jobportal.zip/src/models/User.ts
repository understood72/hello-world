import { Document, Schema, Model, model} from "mongoose";
import { ObjectId } from "bson";

const UserSchema = new Schema({
    user_type_id: Schema.Types.ObjectId,
    name: String,
    email: String,
    password: String,
    dob: Number,
    gender: String,
    status: Number,
    sms_notification_active: Number,
    email_notification_active: Number,
    user_image: String,
    created_at: Number
});

UserSchema.methods.isExist = function(cb: any) {    
    return this.model('users').findOne({email: this.email}, cb);
}
UserSchema.methods.getUsers = function(cb: any) {
    let data = {user_type_id: ''};
    console.log('User type: '+this.user_type_id);
    if(this.user_type_id != undefined && this.user_type_id != '') {
        data.user_type_id = this.user_type_id;
    }
    return model('users').find(data, cb);
}
const User = model('users', UserSchema);
module.exports = User;
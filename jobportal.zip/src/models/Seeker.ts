import { Document, Schema, Model, model} from "mongoose";
import { ObjectId } from "bson";

const SeekerSchema = new Schema({
    user_id: Schema.Types.ObjectId,
    first_name: String,
    last_name: String,
    current_salary: Number,
    is_annually_monthly: {type: String, enum:['Monthly', 'Yearly']},
    currency: String,
    created_at: Number
});

SeekerSchema.methods.isExist = function(cb: any) {
    return this.model('seeker_profile').findOne({email: this.email}, cb);
}


const Seeker = model('seeker_profile', SeekerSchema);
module.exports = Seeker;
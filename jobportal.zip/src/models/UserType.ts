// import  * as mongoose  from "mongoose";
import { Document, Schema, Model, model} from "mongoose";

// var Schema = mongoose.Schema;

const userTypeSchema = new Schema({
    user_type: { type: String }
}, {collection: 'user_type'});

userTypeSchema.methods.isExist = function(cb: any) {
    console.log(this.user_type);
    return this.model('user_type').findOne({user_type: this.user_type}, cb);
}
const UserType = model('user_type', userTypeSchema);
module.exports = UserType;

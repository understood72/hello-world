// import  * as mongoose  from "mongoose";
import { Document, Schema, Model, model} from "mongoose";

// var Schema = mongoose.Schema;

const businessStreamSchema = new Schema({
    name: { type: String }
}, {collection: 'business_stream'});

businessStreamSchema.methods.isExist = function(cb: any) {
    return this.model('business_stream').findOne({name: this.name}, cb);
}
const BusinessStream = model('business_stream', businessStreamSchema);
module.exports = BusinessStream;

class Man {
    name: string;
    constructor(public n: string) {
        this.name = n;
        console.log(this.name);
    }
}
const m = new Man('Amit');